//
//  ViewController.swift
//  Mini-projet
//
//  Created by Mathieu Herique on 08/01/2021.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data_to_display.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let row = indexPath.row
        let cell = itemTableView.dequeueReusableCell(withIdentifier: "itemCell", for: indexPath) as! ItemTableViewCell
        if indexPath.row%2 == 0 {
            cell.backgroundColor = UIColor.systemGray6
        }
        else{
            cell.backgroundColor = UIColor.white
        }
        cell.itemName.text = data_to_display[row].info.name
        cell.itemPrix.text = String(data_to_display[row].info.prix)
        if data_to_display[row].quantitee == 0{
            cell.itemAvailable.text = "Produit indisponible"
            cell.itemAvailable.textColor = UIColor.red
        }
        else{
            cell.itemAvailable.text = "Disponible"
            cell.itemAvailable.textColor = UIColor.systemGreen
        }
        
        cell.itemPicture.load(urlString: data_to_display[row].icone)
        return cell

    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        if let path = Bundle.main.path(forResource: "items", ofType: "json"){
            if let str = try? String(contentsOfFile: path){
                let rawData = Data(str.utf8)
                if let jsonData = try? JSONDecoder().decode(Items.self, from: rawData){
                    data = jsonData.items
                }
                else{
                    errorMessage = "Données ne sont pas de type Json"
                }
            }
            else{
                errorMessage = "Le fichier n'est pas un fichier texte"
            }
        }
        else{
            errorMessage = "Le fichier n'existe pas"
        }
        if let error = errorMessage{
            print(error)
        }
        else{
            for element in data{ // réaliser une liste avec toutes les catégories qui existent en 1 exemplaire
                if !categories.contains(element.category.cat1){
                    categories.append(element.category.cat1)
                }
                if !categories.contains(element.category.cat2){
                    categories.append(element.category.cat2)
                }
            }
        }
        toDisplay()
        itemTableView.dataSource = self
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let vc = segue.destination as? CategoryChooseViewController{
            vc.categories = categories
            vc.selectCategory = selectCategory
            vc.delegate = self
        }
        if let vc = segue.destination as? ItemDetailViewController{
            let row = itemTableView.indexPathForSelectedRow!.row
            vc.data = data_to_display[row]
            vc.delegate = self  
        }
        if let vc = segue.destination as? CarViewController{
            vc.items_in_car = item_in_car
            vc.quantity_in_car = quantity_in_car
            vc.delegate = self
        }
                
        
    }
    
    func toDisplay(){
        data_to_display.removeAll()
        for i in data{
            if((selectCategory.contains("Toutes")) || (selectCategory.contains(i.category.cat1)) ||  (selectCategory.contains(i.category.cat2))){
                data_to_display.append(i)
            }
        }
    }
    
    @IBOutlet weak var itemTableView: UITableView!
    
    var data : [Item] = []
    var data_to_display : [Item] = []
    var errorMessage:String?
    var categories : [String] = ["Toutes"]
    var selectCategory : [String] = ["Toutes"]
    var item_in_car : [Item] = []
    var quantity_in_car : [Int] = []
    
}

