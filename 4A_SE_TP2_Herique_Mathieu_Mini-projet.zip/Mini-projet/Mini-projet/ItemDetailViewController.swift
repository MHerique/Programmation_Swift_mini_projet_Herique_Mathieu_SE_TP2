//
//  ItemDetailViewController.swift
//  Mini-projet
//
//  Created by Mathieu Herique on 18/01/2021.
//

import UIKit

class ItemDetailViewController: UIViewController {

    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var icone: UIImageView!
    @IBOutlet weak var disponible: UILabel!
    @IBOutlet weak var prix: UILabel!
    @IBOutlet weak var item_description: UITextView!
    @IBOutlet weak var add_car: UIButton!
    @IBOutlet weak var Quantity_display: UILabel!
    
    @IBAction func addCarClicked(_ sender: Any) {
        var exist:Bool = false
        var index:Int = 0
        
        for i in delegate.item_in_car{
            if i.info.name == data?.info.name{
                exist = true
            }
            else{
                index += 1
            }
        }
        if exist {
            if data!.quantitee-delegate.quantity_in_car[index] == 0{
                let alert = UIAlertController(title: "Ajout impossible", message: "Aucun article supplémentaire n'est disponible", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Retour", style: .default, handler: nil))
                self.present(alert, animated: true)
            }
            if  data!.quantitee-delegate.quantity_in_car[index]-quantity >= 0{
                delegate.quantity_in_car[index] += 1
            }
            if data!.quantitee-delegate.quantity_in_car[index] == 0{
                add_car.backgroundColor = UIColor.systemGray2
            }
        }
        else if !exist && data!.quantitee-quantity >= 0{
            delegate.item_in_car.append(data!)
            delegate.quantity_in_car.append(quantity)
        }
        
        

            
    }
    
    var delegate : ViewController!
    var data : Item?
    //var data_to_car : Item?
    var quantity = 1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        name.text = data?.info.name
        prix.text = "Prix : " + String(data?.info.prix ?? 0) + "€"
        item_description.text = "Description : " + (data?.info.infoDescription)!
        icone.load(urlString: data?.icone ?? "https://cdn1.iconfinder.com/data/icons/strongicon-vol-05/24/synchronize-23-512.png")
        add_car.backgroundColor = UIColor.systemGreen
        if data?.quantitee == 0{
            disponible.text = "Indisponible"
            disponible.textColor = UIColor.systemRed
        }
        else{
            disponible.text = String(data!.quantitee) + " de disponible"
            disponible.textColor = UIColor.systemGreen
        }
        if data!.quantitee == 0{
            add_car.backgroundColor = UIColor.systemGray
        }
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
