//
//  Items.swift
//  Mini-projet
//
//  Created by Mathieu Herique on 08/01/2021.
//

import Foundation

// This file was generated with GUICKTYPE from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let items = try? newJSONDecoder().decode(Items.self, from: jsonData)

import Foundation

// MARK: - Items
class Items: Codable {
    let items: [Item]

    init(items: [Item]) {
        self.items = items
    }
}

// MARK: - Item
class Item: Codable {
    let category: Category
    let info: Info
    var quantitee: Int
    let icone: String

    init(category: Category, info: Info, quantitee: Int, icone: String) {
        self.category = category
        self.info = info
        self.quantitee = quantitee
        self.icone = icone
    }
}

// MARK: - Category
class Category: Codable {
    let cat1, cat2: String

    init(cat1: String, cat2: String) {
        self.cat1 = cat1
        self.cat2 = cat2
    }
}

// MARK: - Info
class Info: Codable {
    let name: String
    let prix: Double
    let infoDescription: String

    enum CodingKeys: String, CodingKey {
        case name, prix
        case infoDescription = "description"
    }

    init(name: String, prix: Double, infoDescription: String) {
        self.name = name
        self.prix = prix
        self.infoDescription = infoDescription
    }
}
