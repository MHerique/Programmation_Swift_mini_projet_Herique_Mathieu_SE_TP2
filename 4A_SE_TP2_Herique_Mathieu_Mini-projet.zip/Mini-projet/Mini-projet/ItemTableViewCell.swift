//
//  ItemViewCell.swift
//  Mini-projet
//
//  Created by Mathieu Herique on 14/01/2021.
//

import UIKit

class ItemTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    @IBOutlet weak var itemPicture: UIImageView!
    @IBOutlet weak var itemName: UILabel!
    @IBOutlet weak var itemPrix: UILabel!
    @IBOutlet weak var itemAvailable: UILabel!
    
}
