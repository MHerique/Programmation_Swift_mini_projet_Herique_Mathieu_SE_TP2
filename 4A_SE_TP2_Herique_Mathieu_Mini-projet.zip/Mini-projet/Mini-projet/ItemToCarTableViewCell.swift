//
//  ItemToCarTableViewCell.swift
//  Mini-projet
//
//  Created by Mathieu Herique on 20/01/2021.
//

import UIKit

protocol TableViewNew{
    func sup_item_car(index: Int)
    func add_item_car(index: Int)
}

class ItemToCarTableViewCell: UITableViewCell {
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var quantity: UILabel!
    @IBOutlet weak var icone: UIImageView!
    @IBOutlet weak var prix_unitaire: UILabel!
    @IBOutlet weak var total: UILabel!
    @IBOutlet weak var sup_buton: UIButton!
    @IBOutlet weak var add_buton: UIButton!
    
    @IBAction func sup_item(_ sender: UIButton) {
        cell_delegate?.sup_item_car(index: (index?.row)!)
    }
    @IBAction func add_item(_ sender: UIButton) {
        cell_delegate?.add_item_car(index: (index?.row)!)
    }
    
    var cell_delegate: TableViewNew?
    var index: IndexPath?
    
}
