//
//  CategoryChooseViewController.swift
//  Mini-projet
//
//  Created by Mathieu Herique on 14/01/2021.
//

import UIKit

class CategoryChooseViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return categories.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = categoryTableView.dequeueReusableCell(withIdentifier: "categoryCell", for: indexPath) as! CategoryChooseTableViewCell
        let row = indexPath.row
        cell.category.text = categories[row]
        if selectCategory.contains(categories[row]) {
            cell.backgroundColor = UIColor.systemGray5
        }
        return cell
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        categoryTableView.dataSource = self
        categoryTableView.delegate = self
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = categoryTableView.cellForRow(at: indexPath)
        if !selectCategory.contains(categories[indexPath.row]){
            cell?.backgroundColor = UIColor.systemGray5
            selectCategory.append(categories[indexPath.row])
            tableView.deselectRow(at: indexPath, animated: true)
            if( (selectCategory.count != 1) && (selectCategory.contains("Toutes"))){
                selectCategory.remove(at: selectCategory.firstIndex(of: "Toutes")!)
            }
        }
        else{
            cell?.backgroundColor = UIColor.white
            tableView.deselectRow(at: indexPath, animated: true)
            selectCategory.remove(at: selectCategory.firstIndex(of: categories[indexPath.row])!)
            if(selectCategory.count == 0){
                selectCategory.append("Toutes")
            }
        }
        if selectCategory.count == 0{
            selectCategory.append("Toutes")
        }
        
        delegate.selectCategory = selectCategory
        delegate.toDisplay()
        delegate.itemTableView.reloadData()
        tableView.reloadData()
        //dismiss(animated: true, completion: nil) // permet de fermer le view controller
    }
    
   
    
    @IBOutlet weak var categoryTableView: UITableView!
    
    var delegate : ViewController! // avoir le view controller en variable pour lui retourner la liste des catégories
    var categories: [String] = ["toutes"]
    var selectCategory : [String] = ["Toutes"]
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
}
