//
//  CarViewController.swift
//  Mini-projet
//
//  Created by Mathieu Herique on 19/01/2021.
//

import UIKit

class CarViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    

    @IBOutlet weak var Prix_total: UILabel!
    @IBOutlet weak var carTableView: UITableView!
    var items_in_car : [Item]?
    var quantity_in_car : [Int]?
    var  delegate : ViewController!
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items_in_car!.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = carTableView.dequeueReusableCell(withIdentifier: "ItemsCar", for: indexPath) as! ItemToCarTableViewCell
        let row = indexPath.row
        cell.name.text = items_in_car![row].info.name
        cell.prix_unitaire.text = String(items_in_car![row].info.prix) + " €/unité"
        cell.total.text = String(items_in_car![row].info.prix*Double(quantity_in_car![row])) + " €"
        cell.icone.load(urlString: items_in_car![row].icone)
        cell.cell_delegate = self
        cell.index = indexPath
        cell.quantity.text = String(quantity_in_car![row])
        return cell
        
    }
    
    /*func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
        print("test")
    }*/
    
    override func viewDidLoad() {
        super.viewDidLoad()

        carTableView.dataSource = self
        calculTotal()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func accept_buton(_ unwindSegue: UIStoryboardSegue) {
        let sourceViewController = unwindSegue.source
        for i in 0..<items_in_car!.count{
            for j in delegate.data{
                if items_in_car![i].info.name == j.info.name{
                    j.quantitee = j.quantitee-delegate.quantity_in_car[i]
                }
            }
        }
        delegate.item_in_car.removeAll()
        delegate.quantity_in_car.removeAll()
        items_in_car?.removeAll()
        quantity_in_car?.removeAll()
        delegate.toDisplay()
        carTableView.reloadData()
        delegate.itemTableView.reloadData()
        calculTotal()
        

    }
    
    @IBAction func annul_buton(_ unwindSegue: UIStoryboardSegue) {
        let sourceViewController = unwindSegue.source

    }
    
    
    func calculTotal(){
        var sum = 0
        for i in 0..<items_in_car!.count{
            sum = sum + Int(items_in_car![i].info.prix)*quantity_in_car![i]
        }
        Prix_total.text = "Valeur total du panier : " + String(sum) + " €"
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension CarViewController: TableViewNew{
    func sup_item_car(index: Int){
        if quantity_in_car![index] == 1{
            quantity_in_car?.remove(at: index)
            items_in_car?.remove(at: index)
            delegate.item_in_car = items_in_car!
        }
        else{
            quantity_in_car![index] = quantity_in_car![index]-1
        }
        delegate.quantity_in_car=quantity_in_car!
        carTableView.reloadData()
        calculTotal()
        
    }
    
    func add_item_car(index: Int){
        if  delegate.item_in_car[index].quantitee-delegate.quantity_in_car[index]-1 >= 0{
            delegate.quantity_in_car[index] += 1
            quantity_in_car![index] = quantity_in_car![index]+1
            delegate.quantity_in_car = quantity_in_car!
            calculTotal()
            carTableView.reloadData()
        }
        else{
            let alert = UIAlertController(title: "Ajout impossible", message: "Aucun article supplémentaire n'est disponible", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Retour", style: .default, handler: nil))
            self.present(alert, animated: true)
        }
       
    }
}
